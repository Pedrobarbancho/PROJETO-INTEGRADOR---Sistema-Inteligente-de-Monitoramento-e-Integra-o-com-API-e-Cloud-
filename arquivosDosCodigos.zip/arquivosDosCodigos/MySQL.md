-- ============================================================
-- BANCO DE DADOS IoT - SENAI
-- Versão: MySQL
-- Para SQL Server: veja os comentários marcados com [SS]
-- ============================================================

-- [SS] No SQL Server: remova o IF EXISTS e use:
--      IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'GJP')
--      CREATE DATABASE GJP;
--      GO
CREATE DATABASE IF NOT EXISTS GJP;
USE GJP;

-- ============================================================
-- TABELA: dispositivos
-- Registra cada ESP8266/Arduino pela MAC address
-- ============================================================
CREATE TABLE IF NOT EXISTS dispositivos (
    id_dispositivo  INT          PRIMARY KEY AUTO_INCREMENT,  -- [SS] IDENTITY(1,1)
    mac_address     VARCHAR(25)  NOT NULL UNIQUE,             -- corrigido: era mac_addres
    local_disp      VARCHAR(50)  DEFAULT 'Laboratorio SENAI',
    ultima_conexao  DATETIME     DEFAULT NULL
);

-- ============================================================
-- TABELA: leituras
-- Uma linha por envio do sensor
-- ============================================================
CREATE TABLE IF NOT EXISTS leituras (
    id_leitura      INT           PRIMARY KEY AUTO_INCREMENT, -- [SS] IDENTITY(1,1)
    id_dispositivo  INT           NOT NULL,
    temperatura     DECIMAL(5,2)  NOT NULL,
    umidade         DECIMAL(5,2)  NOT NULL,
    potenciometro   INT           DEFAULT 0,
    rotacao         INT           DEFAULT 0,
    data_hora       DATETIME      DEFAULT NOW(),              -- [SS] DEFAULT GETDATE()
    FOREIGN KEY (id_dispositivo) REFERENCES dispositivos(id_dispositivo)
);

-- ============================================================
-- TABELA: usuario
-- Senhas criptografadas com AES_ENCRYPT no MySQL
-- [SS] No SQL Server use HASHBYTES('SHA2_256', senha)
-- ============================================================
CREATE TABLE IF NOT EXISTS usuario (
    id      INT          PRIMARY KEY AUTO_INCREMENT,          -- [SS] IDENTITY(1,1)
    nome    VARCHAR(100) NOT NULL,
    login   VARCHAR(50)  NOT NULL UNIQUE,
    senha   VARBINARY(255) NOT NULL,
    perfil  VARCHAR(20)  NOT NULL,
    -- Perfis válidos: 'Operador', 'Supervisor', 'Admin'
    CHECK (perfil IN ('Operador', 'Supervisor', 'Admin'))
);

-- ============================================================
-- TABELA: alertas_logs
-- [SS] Não tem ENUM — use VARCHAR + CHECK CONSTRAINT
-- ============================================================
CREATE TABLE IF NOT EXISTS alertas_logs (
    id_log    INT          PRIMARY KEY AUTO_INCREMENT,        -- [SS] IDENTITY(1,1)
    nivel     ENUM('INFO', 'ALERTA', 'ERRO') NOT NULL,       -- [SS] VARCHAR(10) CHECK (nivel IN (...))
    mensagem  TEXT         NOT NULL,                          -- [SS] NVARCHAR(MAX)
    wifi_rssi INT          DEFAULT 0,
    data_hora DATETIME     DEFAULT NOW()                      -- [SS] DEFAULT GETDATE()
);

-- ============================================================
-- USUÁRIO ADMIN INICIAL (execute uma vez após criar o banco)
-- Substitua 'SUA_CHAVE_AES' pela mesma que está no .env
-- ============================================================
-- INSERT INTO usuario (nome, login, senha, perfil)
-- VALUES ('Administrador', 'admin', AES_ENCRYPT('senha_inicial', 'SUA_CHAVE_AES'), 'Admin');


-- ============================================================
-- CONSULTAS ÚTEIS PARA DEBUG
-- ============================================================

-- Ver últimas 10 leituras com o MAC do dispositivo:
-- SELECT d.mac_address, l.temperatura, l.umidade, l.data_hora
-- FROM leituras l
-- JOIN dispositivos d ON l.id_dispositivo = d.id_dispositivo
-- ORDER BY l.data_hora DESC
-- LIMIT 10;                                    -- [SS] TOP 10 no SELECT, sem LIMIT

-- Ver alertas recentes:
-- SELECT nivel, mensagem, data_hora FROM alertas_logs ORDER BY data_hora DESC LIMIT 20;

-- Ver usuários (sem expor senha):
-- SELECT id, nome, login, perfil FROM usuario;
