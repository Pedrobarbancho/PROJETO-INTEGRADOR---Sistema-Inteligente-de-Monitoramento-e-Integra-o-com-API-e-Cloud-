"""
API IoT - SENAI v3
- Fix: load_dotenv(override=True) garante leitura correta do .env
- Novo: sistema de sessão simples (sem expor o API_TOKEN no frontend)
- Novo: rotas de dados com controle por perfil (Operador / Supervisor / Admin)
- Mantido: suporte MySQL hoje, SQL Server amanhã via DB_MODE
"""

import os
import uuid
import urllib
import asyncio
import warnings
from datetime import datetime

from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine, text
import uvicorn
from dotenv import load_dotenv

# Google Sheets
try:
    import gspread
    from oauth2client.service_account import ServiceAccountCredentials
    SHEETS_DISPONIVEL = True
except ImportError:
    SHEETS_DISPONIVEL = False

# ⚠️  override=True: força leitura do .env mesmo se a variável já existir no sistema
load_dotenv(override=True)


# ======================================================
# ⚙️  MODO DO BANCO
# ======================================================
DB_MODE = os.getenv("DB_MODE", "mysql")  # troque para "mysql" para usar MySQL e for SQL Server usa "sqlserver"


# ======================================================
# 🗄️  ENGINE DO BANCO
# ======================================================
def criar_engine():
    if DB_MODE == "mysql":
        url = os.getenv("MYSQL_URL")
        if not url:
            raise RuntimeError("MYSQL_URL não definida no .env")
        return create_engine(url, connect_args={"connect_timeout": 5}, pool_pre_ping=True)

    elif DB_MODE == "sqlserver":
        driver = os.getenv("SQLSERVER_DRIVER", "{SQL Server}")
        server = os.getenv("SQLSERVER_SERVER", r".\SQLEXPRESS")
        db     = os.getenv("SQLSERVER_DB", "GJP")
        params = urllib.parse.quote_plus(
            f"DRIVER={driver};SERVER={server};DATABASE={db};Trusted_Connection=yes;"
        )
        return create_engine(
            f"mssql+pyodbc:///?odbc_connect={params}",
            connect_args={"timeout": 5},
            pool_pre_ping=True
        )

    raise RuntimeError(f"DB_MODE inválido: '{DB_MODE}'")


try:
    engine = criar_engine()
    print(f"✅ Banco conectado: {DB_MODE.upper()}")
except Exception as e:
    engine = None
    print(f"❌ Falha ao conectar banco: {e}")


# ======================================================
# 🔀  SQL COMPATÍVEL COM AMBOS OS BANCOS
# ======================================================
def sql(mysql_q: str, ss_q: str) -> str:
    return mysql_q if DB_MODE == "mysql" else ss_q


# Leituras de sensores
Q_INSERT_DISPOSITIVO = sql(
    "INSERT INTO dispositivos (mac_address, local_disp) VALUES (:m, :l)",
    "INSERT INTO dispositivos (mac_address, local_disp) VALUES (:m, :l)"
)
Q_SELECT_DISPOSITIVO = "SELECT id_dispositivo FROM dispositivos WHERE mac_address = :m"
Q_INSERT_LEITURA = sql(
    "INSERT INTO leituras (id_dispositivo, temperatura, umidade, data_hora) VALUES (:id, :t, :u, NOW())",
    "INSERT INTO leituras (id_dispositivo, temperatura, umidade, data_hora) VALUES (:id, :t, :u, GETDATE())"
)
Q_INSERT_ALERTA = sql(
    "INSERT INTO alertas_logs (nivel, mensagem, wifi_rssi, data_hora) VALUES (:nivel, :msg, :rssi, NOW())",
    "INSERT INTO alertas_logs (nivel, mensagem, wifi_rssi, data_hora) VALUES (:nivel, :msg, :rssi, GETDATE())"
)

# Usuários
Q_LOGIN = sql(
    "SELECT nome, perfil FROM usuario WHERE login = :login AND senha = AES_ENCRYPT(:senha, :chave)",
    "SELECT nome, perfil FROM usuario WHERE login = :login AND senha = HASHBYTES('SHA2_256', :senha)"
)
Q_INSERT_USUARIO = sql(
    "INSERT INTO usuario (nome, login, senha, perfil) VALUES (:nome, :login, AES_ENCRYPT(:senha, :chave), :perfil)",
    "INSERT INTO usuario (nome, login, senha, perfil) VALUES (:nome, :login, HASHBYTES('SHA2_256', :senha), :perfil)"
)
Q_LISTAR_USUARIOS = "SELECT id, nome, login, perfil FROM usuario ORDER BY perfil, nome"

# Dados para o dashboard (Operador vê só o básico)
Q_LEITURAS_RECENTES = sql(
    """SELECT d.mac_address, l.temperatura, l.umidade, l.data_hora
       FROM leituras l
       JOIN dispositivos d ON l.id_dispositivo = d.id_dispositivo
       ORDER BY l.data_hora DESC
       LIMIT :n""",
    """SELECT TOP (:n) d.mac_address, l.temperatura, l.umidade, l.data_hora
       FROM leituras l
       JOIN dispositivos d ON l.id_dispositivo = d.id_dispositivo
       ORDER BY l.data_hora DESC"""
)
Q_ALERTAS_RECENTES = sql(
    "SELECT nivel, mensagem, wifi_rssi, data_hora FROM alertas_logs ORDER BY data_hora DESC LIMIT :n",
    "SELECT TOP (:n) nivel, mensagem, wifi_rssi, data_hora FROM alertas_logs ORDER BY data_hora DESC"
)
Q_DISPOSITIVOS = "SELECT id_dispositivo, mac_address, local_disp, ultima_conexao FROM dispositivos"


# ======================================================
# 📊  GOOGLE SHEETS
# ======================================================
aba_leituras = aba_alertas = aba_usuarios = None

if SHEETS_DISPONIVEL:
    try:
        scope      = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
        creds      = ServiceAccountCredentials.from_json_keyfile_name(
                        os.getenv("GOOGLE_CREDS_FILE", "credenciais.json"), scope)
        gclient    = gspread.authorize(creds)
        planilha   = gclient.open(os.getenv("GOOGLE_SHEET_NAME", "Planilha de dados"))
        aba_leituras = planilha.worksheet("leituras")
        aba_alertas  = planilha.worksheet("alertas")
        aba_usuarios = planilha.worksheet("usuarios")
        print("✅ Google Sheets conectado.")
    except Exception as e:
        print(f"⚠️  Sheets indisponível: {e}")


# ======================================================
# 🔐  SISTEMA DE SESSÃO SIMPLES
# Gerado no login, armazenado em memória, enviado pelo frontend
# Sem expiração por tempo (simplificado para o projeto escolar)
# ======================================================
sessoes: dict[str, dict] = {}
# Formato: { "token-uuid": {"nome": ..., "perfil": ...} }

def criar_sessao(nome: str, perfil: str) -> str:
    token = str(uuid.uuid4())
    sessoes[token] = {"nome": nome, "perfil": perfil}
    return token

def obter_sessao(x_session: str = Header(None)) -> dict:
    """Dependência do FastAPI: valida sessão e retorna dados do usuário."""
    if not x_session or x_session not in sessoes:
        raise HTTPException(status_code=401, detail="Sessão inválida. Faça login novamente.")
    return sessoes[x_session]

def exigir_perfil(*perfis_permitidos: str):
    """Dependência com perfil mínimo exigido."""
    def verificar(sessao: dict = Depends(obter_sessao)):
        if sessao["perfil"] not in perfis_permitidos:
            raise HTTPException(status_code=403, detail=f"Acesso negado. Perfis permitidos: {list(perfis_permitidos)}")
        return sessao
    return verificar


# ======================================================
# 🚀  FASTAPI
# ======================================================
app = FastAPI(title="API IoT - SENAI", version="3.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

API_TOKEN  = os.getenv("API_TOKEN")
SECRET_KEY = os.getenv("SECRET_KEY_DB")

ultimos_contatos: dict = {}


# ======================================================
# 📦  MODELOS
# ======================================================
class Sensores(BaseModel):
    temperatura: float
    umidade: float
    rotacao: int = 0
    potenciometro: int = 0

class Entradas(BaseModel):
    botao1: bool = False
    botao2: bool = False
    ir_recebido: bool = False

class ESPPayload(BaseModel):
    device: str
    timestamp_ms: int
    sensores: Sensores
    entradas: Entradas
    status: str = "ok"
    wifi_rssi: int = 0

class NovoUsuario(BaseModel):
    nome: str
    login: str
    senha: str
    perfil: str

class LoginRequest(BaseModel):
    login: str
    senha: str


# ======================================================
# 🛠️  HELPERS
# ======================================================
def salvar_alerta(nivel: str, mensagem: str, rssi: int = 0):
    agora_str = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    if engine:
        try:
            with engine.connect() as conn:
                conn.execute(text(Q_INSERT_ALERTA), {"nivel": nivel, "msg": mensagem, "rssi": rssi})
                conn.commit()
        except Exception as e:
            print(f"⚠️  Erro ao salvar alerta: {e}")
    if aba_alertas:
        try:
            aba_alertas.append_row([agora_str, nivel, mensagem, f"{rssi} dBm"])
        except Exception as e:
            print(f"⚠️  Erro Sheets alerta: {e}")

async def monitorar_conexoes():
    while True:
        agora = datetime.now()
        for mac, info in list(ultimos_contatos.items()):
            if (agora - info["horario"]).total_seconds() > 30 and info["status"] == "online":
                salvar_alerta("ALERTA", f"Dispositivo '{mac}' parou de responder!")
                ultimos_contatos[mac]["status"] = "offline"
                print(f"❌ ALERTA: {mac} offline")
        await asyncio.sleep(5)


# ======================================================
# 🛣️  ROTAS PÚBLICAS (sem sessão)
# ======================================================

@app.get("/hora")
async def fornecer_hora():
    return {"datahora": datetime.now().strftime("%d/%m/%Y %H:%M:%S")}


@app.get("/status")
async def status_api():
    return {
        "api": "online",
        "banco": DB_MODE,
        "banco_conectado": engine is not None,
        "sheets_conectado": aba_leituras is not None,
    }


@app.post("/login")
async def login(req: LoginRequest):
    # Atalho dev — REMOVER antes de apresentar
    if req.login == "admin" and req.senha == "123":
        token = criar_sessao("Desenvolvedor", "Admin")
        return {"nome": "Desenvolvedor", "perfil": "Admin", "session_token": token}

    if not engine:
        raise HTTPException(status_code=503, detail="Banco indisponível")

    try:
        with engine.connect() as conn:
            res = conn.execute(
                text(Q_LOGIN),
                {"login": req.login, "senha": req.senha, "chave": SECRET_KEY}
            ).fetchone()

        if res:
            token = criar_sessao(res[0], res[1])
            return {"nome": res[0], "perfil": res[1], "session_token": token}

        raise HTTPException(status_code=401, detail="Usuário ou senha incorretos")

    except HTTPException:
        raise
    except Exception as e:
        print(f"Erro login: {e}")
        raise HTTPException(status_code=500, detail="Erro interno ao autenticar")


# ======================================================
# 🛣️  ROTAS DO ESP8266 (protegidas por API_TOKEN do hardware)
# ======================================================

@app.post("/dados")
async def receber_dados(payload: ESPPayload, x_token: str = Header(None)):
    if x_token != API_TOKEN:
        salvar_alerta("ERRO", f"Token inválido de: {payload.device}", payload.wifi_rssi)
        raise HTTPException(status_code=401, detail="Token inválido")

    if not engine:
        raise HTTPException(status_code=503, detail="Banco indisponível")

    agora     = datetime.now()
    agora_str = agora.strftime("%d/%m/%Y %H:%M:%S")
    mac       = payload.device
    temp      = payload.sensores.temperatura
    umid      = payload.sensores.umidade
    id_disp   = None
    st_banco  = "⚪ Falhou"
    st_sheets = "⚪ Desativado"

    try:
        with engine.connect() as conn:
            res = conn.execute(text(Q_SELECT_DISPOSITIVO), {"m": mac}).fetchone()
            if not res:
                conn.execute(text(Q_INSERT_DISPOSITIVO), {"m": mac, "l": "Laboratorio SENAI"})
                conn.commit()
                res = conn.execute(text(Q_SELECT_DISPOSITIVO), {"m": mac}).fetchone()
            id_disp = res[0]
            conn.execute(text(Q_INSERT_LEITURA), {"id": id_disp, "t": temp, "u": umid})
            conn.commit()
            st_banco = "✅ Sucesso"
    except Exception as e:
        print(f"⚠️  Banco: {e}")

    if aba_leituras:
        try:
            aba_leituras.append_row([agora_str, mac, temp, umid, payload.wifi_rssi])
            st_sheets = "✅ Sucesso"
        except Exception as e:
            st_sheets = f"⚠️  {e}"

    if mac in ultimos_contatos and ultimos_contatos[mac]["status"] == "offline":
        salvar_alerta("INFO", f"Dispositivo {mac} voltou a operar.", payload.wifi_rssi)

    ultimos_contatos[mac] = {
        "id": id_disp, "local": "Laboratorio SENAI",
        "horario": agora, "status": "online",
        "temperatura": temp, "umidade": umid, "rssi": payload.wifi_rssi,
    }

    print(f"\n{'─'*50}")
    print(f"  💾 Banco ({DB_MODE}): {st_banco}  📊 Sheets: {st_sheets}")
    print(f"  🌡️  {temp}°C  💧 {umid}%  📶 {payload.wifi_rssi} dBm  🤖 {mac}")
    print(f"{'─'*50}")

    return {"status": "recebido", "id": id_disp}


# ======================================================
# 🛣️  ROTAS DO DASHBOARD (protegidas por sessão)
# ======================================================

@app.get("/dados_recentes")
async def dados_recentes(sessao: dict = Depends(obter_sessao)):
    """Qualquer usuário logado vê os dados em tempo real."""
    if not ultimos_contatos:
        return {"online": False}
    ultimo = list(ultimos_contatos.values())[-1]
    return {
        "online": ultimo["status"] == "online",
        "temperatura": ultimo.get("temperatura", 0),
        "umidade":     ultimo.get("umidade", 0),
        "rssi":        ultimo.get("rssi", 0),
        "horario":     ultimo["horario"].strftime("%d/%m/%Y %H:%M:%S"),
    }


@app.get("/tabela/leituras")
async def tabela_leituras(n: int = 20, sessao: dict = Depends(obter_sessao)):
    """
    Operador, Supervisor e Admin veem as leituras.
    Operador vê menos colunas (sem mac_address) — feito no frontend.
    """
    if not engine:
        raise HTTPException(status_code=503, detail="Banco indisponível")
    try:
        with engine.connect() as conn:
            rows = conn.execute(text(Q_LEITURAS_RECENTES), {"n": n}).fetchall()
        return [
            {"mac": r[0], "temperatura": float(r[1]), "umidade": float(r[2]),
             "data_hora": r[3].strftime("%d/%m/%Y %H:%M:%S")}
            for r in rows
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/tabela/alertas")
async def tabela_alertas(
    n: int = 20,
    sessao: dict = Depends(exigir_perfil("Supervisor", "Admin"))
):
    """Apenas Supervisor e Admin veem alertas."""
    if not engine:
        raise HTTPException(status_code=503, detail="Banco indisponível")
    try:
        with engine.connect() as conn:
            rows = conn.execute(text(Q_ALERTAS_RECENTES), {"n": n}).fetchall()
        return [
            {"nivel": r[0], "mensagem": r[1], "rssi": r[2],
             "data_hora": r[3].strftime("%d/%m/%Y %H:%M:%S")}
            for r in rows
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/tabela/usuarios")
async def tabela_usuarios(sessao: dict = Depends(exigir_perfil("Admin"))):
    """Apenas Admin vê a lista de usuários."""
    if not engine:
        raise HTTPException(status_code=503, detail="Banco indisponível")
    try:
        with engine.connect() as conn:
            rows = conn.execute(text(Q_LISTAR_USUARIOS)).fetchall()
        return [{"id": r[0], "nome": r[1], "login": r[2], "perfil": r[3]} for r in rows]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/tabela/dispositivos")
async def tabela_dispositivos(
    sessao: dict = Depends(exigir_perfil("Supervisor", "Admin"))
):
    """Supervisor e Admin veem dispositivos cadastrados."""
    if not engine:
        raise HTTPException(status_code=503, detail="Banco indisponível")
    try:
        with engine.connect() as conn:
            rows = conn.execute(text(Q_DISPOSITIVOS)).fetchall()
        return [
            {"id": r[0], "mac": r[1], "local": r[2],
             "ultima_conexao": r[3].strftime("%d/%m/%Y %H:%M:%S") if r[3] else "—"}
            for r in rows
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/cadastrar_usuario")
async def cadastrar_usuario(
    usuario: NovoUsuario,
    sessao: dict = Depends(exigir_perfil("Supervisor", "Admin"))
):
    """
    Supervisor pode criar Operadores.
    Admin pode criar qualquer perfil.
    Não expõe o API_TOKEN — a autorização é pela sessão.
    """
    perfis_validos = {"Operador", "Supervisor", "Admin"}
    if usuario.perfil not in perfis_validos:
        raise HTTPException(status_code=400, detail=f"Perfil inválido. Use: {perfis_validos}")

    # Supervisor não pode criar Admin
    if sessao["perfil"] == "Supervisor" and usuario.perfil == "Admin":
        raise HTTPException(status_code=403, detail="Supervisores não podem criar Admins.")

    if not engine:
        raise HTTPException(status_code=503, detail="Banco indisponível")

    try:
        with engine.connect() as conn:
            conn.execute(
                text(Q_INSERT_USUARIO),
                {"nome": usuario.nome, "login": usuario.login,
                 "senha": usuario.senha, "chave": SECRET_KEY, "perfil": usuario.perfil}
            )
            conn.commit()

        # Espelha no Sheets se disponível
        if aba_usuarios:
            try:
                agora_str = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
                aba_usuarios.append_row([agora_str, usuario.nome, usuario.login, usuario.perfil])
            except Exception:
                pass

        return {"status": "sucesso", "mensagem": f"Usuário '{usuario.login}' criado com perfil '{usuario.perfil}'."}
    except Exception:
        raise HTTPException(status_code=400, detail="Login já existe ou erro no banco.")


# ======================================================
# 🚀  INICIALIZAÇÃO
# ======================================================
if __name__ == "__main__":
    warnings.filterwarnings("ignore", category=DeprecationWarning)
    print("\n" + "="*52)
    print(f"  🚀 API IoT SENAI v3 — Banco: {DB_MODE.upper()}")
    print("="*52 + "\n")

    config = uvicorn.Config(app, host="0.0.0.0", port=5000, log_level="error")
    srv    = uvicorn.Server(config)

    async def main():
        asyncio.create_task(monitorar_conexoes())
        await srv.serve()

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 API finalizada.")   