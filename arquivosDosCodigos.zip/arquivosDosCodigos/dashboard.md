<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IoT SENAI — Dashboard</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Barlow:wght@300;500;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg:      #0a0e14;
      --surface: #111820;
      --border:  #1e3048;
      --accent:  #00d4ff;
      --accent2: #00ff9d;
      --warn:    #ffb347;
      --danger:  #ff4c60;
      --text:    #c8d8e8;
      --muted:   #4a6a8a;
      --mono:    'Share Tech Mono', monospace;
      --sans:    'Barlow', sans-serif;
    }

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      background: var(--bg);
      color: var(--text);
      font-family: var(--sans);
      min-height: 100vh;
    }

    body::before {
      content: '';
      position: fixed;
      inset: 0;
      background-image:
        linear-gradient(rgba(0,212,255,.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,212,255,.03) 1px, transparent 1px);
      background-size: 40px 40px;
      pointer-events: none;
      z-index: 0;
    }

    /* ── NAV ── */
    nav {
      position: relative;
      z-index: 10;
      background: var(--surface);
      border-bottom: 1px solid var(--border);
      padding: 0 32px;
      height: 56px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .nav-brand {
      font-family: var(--mono);
      font-size: 12px;
      letter-spacing: 3px;
      color: var(--accent);
      text-transform: uppercase;
    }

    .nav-right {
      display: flex;
      align-items: center;
      gap: 24px;
      font-family: var(--mono);
      font-size: 11px;
      color: var(--muted);
    }

    .badge-perfil {
      padding: 3px 10px;
      border: 1px solid var(--border);
      color: var(--accent2);
      font-size: 10px;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .btn-sair {
      background: transparent;
      border: 1px solid var(--danger);
      color: var(--danger);
      font-family: var(--mono);
      font-size: 10px;
      letter-spacing: 2px;
      padding: 6px 14px;
      cursor: pointer;
      text-transform: uppercase;
      transition: background .2s, color .2s;
    }
    .btn-sair:hover { background: var(--danger); color: var(--bg); }

    /* ── MAIN ── */
    main {
      position: relative;
      z-index: 1;
      padding: 32px;
      max-width: 1100px;
      margin: 0 auto;
    }

    .section-title {
      font-family: var(--mono);
      font-size: 10px;
      letter-spacing: 3px;
      color: var(--muted);
      text-transform: uppercase;
      margin-bottom: 16px;
    }

    /* ── CARDS DE SENSORES ── */
    .sensor-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin-bottom: 32px;
    }

    .sensor-card {
      background: var(--surface);
      border: 1px solid var(--border);
      padding: 28px 24px;
      position: relative;
      animation: fadeUp .4s ease both;
    }
    .sensor-card:nth-child(2) { animation-delay: .08s; }
    .sensor-card:nth-child(3) { animation-delay: .16s; }

    .sensor-card::before {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0;
      height: 2px;
      background: var(--accent);
    }

    .sensor-label {
      font-family: var(--mono);
      font-size: 10px;
      letter-spacing: 3px;
      color: var(--muted);
      text-transform: uppercase;
      margin-bottom: 12px;
    }

    .sensor-value {
      font-family: var(--mono);
      font-size: 44px;
      color: var(--accent);
      line-height: 1;
    }

    .sensor-unit {
      font-size: 16px;
      color: var(--muted);
    }

    /* Card de status */
    .status-card .sensor-card::before { background: var(--accent2); }
    .status-online  { color: var(--accent2) !important; }
    .status-offline { color: var(--danger)  !important; }

    /* ── STATUS / INFO ── */
    .info-row {
      display: flex;
      gap: 16px;
      margin-bottom: 32px;
      flex-wrap: wrap;
    }

    .info-pill {
      background: var(--surface);
      border: 1px solid var(--border);
      padding: 10px 18px;
      font-family: var(--mono);
      font-size: 11px;
      color: var(--muted);
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .dot {
      width: 7px; height: 7px;
      border-radius: 50%;
      background: var(--muted);
      flex-shrink: 0;
    }
    .dot.on  { background: var(--accent2); box-shadow: 0 0 6px var(--accent2); }
    .dot.off { background: var(--danger); }

    /* ── SEÇÃO ADMIN ── */
    .admin-section {
      background: var(--surface);
      border: 1px solid var(--border);
      padding: 28px;
      display: none; /* exibido via JS para Admin */
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr 1fr auto;
      gap: 12px;
      align-items: end;
      flex-wrap: wrap;
    }

    .form-group label {
      display: block;
      font-family: var(--mono);
      font-size: 10px;
      letter-spacing: 2px;
      color: var(--muted);
      text-transform: uppercase;
      margin-bottom: 6px;
    }

    .form-group input,
    .form-group select {
      width: 100%;
      background: var(--bg);
      border: 1px solid var(--border);
      color: var(--text);
      font-family: var(--mono);
      font-size: 13px;
      padding: 10px 12px;
      outline: none;
      transition: border-color .2s;
    }
    .form-group input:focus,
    .form-group select:focus { border-color: var(--accent); }

    .form-group select option { background: var(--surface); }

    .btn-criar {
      background: transparent;
      border: 1px solid var(--accent2);
      color: var(--accent2);
      font-family: var(--mono);
      font-size: 11px;
      letter-spacing: 2px;
      padding: 10px 20px;
      cursor: pointer;
      text-transform: uppercase;
      white-space: nowrap;
      transition: background .2s, color .2s;
    }
    .btn-criar:hover { background: var(--accent2); color: var(--bg); }

    #admin-msg {
      margin-top: 12px;
      font-family: var(--mono);
      font-size: 11px;
      min-height: 16px;
      color: var(--accent2);
    }
    #admin-msg.erro { color: var(--danger); }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(12px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 700px) {
      .form-row { grid-template-columns: 1fr; }
      main { padding: 16px; }
    }
  </style>
</head>
<body>

  <nav>
    <div class="nav-brand">SENAI // IoT Dashboard</div>
    <div class="nav-right">
      <span id="nav-usuario">—</span>
      <span class="badge-perfil" id="nav-perfil">—</span>
      <button class="btn-sair" onclick="sair()">Sair</button>
    </div>
  </nav>

  <main>
    <!-- Status geral -->
    <div class="info-row">
      <div class="info-pill"><span class="dot" id="dot-api"></span><span id="txt-api">API...</span></div>
      <div class="info-pill"><span class="dot" id="dot-sensor"></span><span id="txt-sensor">Sensor...</span></div>
      <div class="info-pill" id="pill-horario" style="display:none">🕒 <span id="txt-horario">—</span></div>
    </div>

    <!-- Leituras -->
    <div class="section-title">// Leituras em tempo real</div>
    <div class="sensor-grid">
      <div class="sensor-card">
        <div class="sensor-label">🌡️ Temperatura</div>
        <div class="sensor-value" id="val-temp">--<span class="sensor-unit">°C</span></div>
      </div>
      <div class="sensor-card">
        <div class="sensor-label">💧 Umidade</div>
        <div class="sensor-value" id="val-umid">--<span class="sensor-unit">%</span></div>
      </div>
      <div class="sensor-card">
        <div class="sensor-label">📶 Sinal Wi-Fi</div>
        <div class="sensor-value" id="val-rssi">--<span class="sensor-unit">dBm</span></div>
      </div>
    </div>

    <!-- Seção Admin: cadastrar usuário -->
    <div class="admin-section" id="admin-section">
      <div class="section-title">// Gerenciar usuários — Admin</div>
      <div class="form-row">
        <div class="form-group">
          <label>Nome</label>
          <input type="text" id="a-nome" placeholder="Nome completo">
        </div>
        <div class="form-group">
          <label>Login</label>
          <input type="text" id="a-login" placeholder="login">
        </div>
        <div class="form-group">
          <label>Senha</label>
          <input type="password" id="a-senha" placeholder="••••••••">
        </div>
        <div class="form-group">
          <label>Perfil</label>
          <select id="a-perfil">
            <option value="Operador">Operador</option>
            <option value="Supervisor">Supervisor</option>
            <option value="Admin">Admin</option>
          </select>
        </div>
        <button class="btn-criar" onclick="criarUsuario()">Criar</button>
      </div>
      <div id="admin-msg"></div>
    </div>
  </main>

  <script>
    const API = 'http://127.0.0.1:5000';

    // Lê sessão — se não existir, manda pro login
    const usuario = sessionStorage.getItem('usuario');
    const perfil  = sessionStorage.getItem('perfil');
    const TOKEN   = 'troque_por_um_token_longo_e_aleatorio_aqui'; // mesmo do .env — só para cadastro

    if (!usuario) {
      window.location.href = 'index.html';
    } else {
      document.getElementById('nav-usuario').textContent = usuario;
      document.getElementById('nav-perfil').textContent  = perfil;

      // Mostra seção admin apenas para Admin
      if (perfil === 'Admin') {
        document.getElementById('admin-section').style.display = 'block';
      }
    }

    function sair() {
      sessionStorage.clear();
      window.location.href = 'index.html';
    }

    // ── Atualização de dados ──
    async function atualizar() {
      try {
        const r = await fetch(`${API}/dados_recentes`, { signal: AbortSignal.timeout(3000) });
        const d = await r.json();

        document.getElementById('dot-api').className = 'dot on';
        document.getElementById('txt-api').textContent = 'API online';

        if (d.online) {
          document.getElementById('dot-sensor').className = 'dot on';
          document.getElementById('txt-sensor').textContent = 'Sensor online';
          document.getElementById('val-temp').innerHTML = `${d.temperatura.toFixed(1)}<span class="sensor-unit">°C</span>`;
          document.getElementById('val-umid').innerHTML = `${d.umidade.toFixed(1)}<span class="sensor-unit">%</span>`;
          document.getElementById('val-rssi').innerHTML = `${d.rssi}<span class="sensor-unit">dBm</span>`;
          document.getElementById('pill-horario').style.display = 'flex';
          document.getElementById('txt-horario').textContent = d.horario;
        } else {
          document.getElementById('dot-sensor').className = 'dot off';
          document.getElementById('txt-sensor').textContent = 'Aguardando sensor...';
        }
      } catch {
        document.getElementById('dot-api').className = 'dot off';
        document.getElementById('txt-api').textContent = 'API offline';
        document.getElementById('dot-sensor').className = 'dot';
        document.getElementById('txt-sensor').textContent = '—';
      }
    }

    // ── Cadastrar usuário (Admin) ──
    async function criarUsuario() {
      const msg   = document.getElementById('admin-msg');
      const body  = {
        nome:   document.getElementById('a-nome').value.trim(),
        login:  document.getElementById('a-login').value.trim(),
        senha:  document.getElementById('a-senha').value,
        perfil: document.getElementById('a-perfil').value,
      };

      if (!body.nome || !body.login || !body.senha) {
        msg.className = 'erro';
        msg.textContent = 'Preencha todos os campos.';
        return;
      }

      msg.className = '';
      msg.textContent = 'Criando...';

      try {
        const r = await fetch(`${API}/cadastrar_usuario`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Token': TOKEN
          },
          body: JSON.stringify(body),
          signal: AbortSignal.timeout(5000)
        });
        const d = await r.json();

        if (r.ok) {
          msg.className = '';
          msg.textContent = `✓ ${d.mensagem}`;
          ['a-nome','a-login','a-senha'].forEach(id => document.getElementById(id).value = '');
        } else {
          msg.className = 'erro';
          msg.textContent = d.detail || 'Erro ao criar usuário.';
        }
      } catch {
        msg.className = 'erro';
        msg.textContent = 'Sem resposta da API.';
      }
    }

    atualizar();
    setInterval(atualizar, 3000);
  </script>
</body>
</html>
