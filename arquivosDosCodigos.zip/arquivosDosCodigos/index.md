<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IoT SENAI — Acesso</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Barlow:wght@300;500;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg:        #0a0e14;
      --surface:   #111820;
      --border:    #1e3048;
      --accent:    #00d4ff;
      --accent2:   #00ff9d;
      --danger:    #ff4c60;
      --text:      #c8d8e8;
      --muted:     #4a6a8a;
      --mono:      'Share Tech Mono', monospace;
      --sans:      'Barlow', sans-serif;
    }

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      background: var(--bg);
      color: var(--text);
      font-family: var(--sans);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
    }

    /* Grade de fundo */
    body::before {
      content: '';
      position: fixed;
      inset: 0;
      background-image:
        linear-gradient(rgba(0,212,255,.04) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,212,255,.04) 1px, transparent 1px);
      background-size: 40px 40px;
      pointer-events: none;
    }

    .card {
      position: relative;
      background: var(--surface);
      border: 1px solid var(--border);
      width: 380px;
      padding: 40px 36px;
      animation: fadeUp .5s ease both;
    }

    /* Canto decorativo */
    .card::before, .card::after {
      content: '';
      position: absolute;
      width: 18px; height: 18px;
      border-color: var(--accent);
      border-style: solid;
    }
    .card::before { top: -1px; left: -1px; border-width: 2px 0 0 2px; }
    .card::after  { bottom: -1px; right: -1px; border-width: 0 2px 2px 0; }

    .logo {
      font-family: var(--mono);
      font-size: 11px;
      color: var(--accent);
      letter-spacing: 3px;
      text-transform: uppercase;
      margin-bottom: 8px;
    }

    h1 {
      font-size: 22px;
      font-weight: 700;
      color: #fff;
      margin-bottom: 32px;
      line-height: 1.2;
    }

    h1 span {
      color: var(--accent);
    }

    label {
      display: block;
      font-family: var(--mono);
      font-size: 10px;
      letter-spacing: 2px;
      color: var(--muted);
      text-transform: uppercase;
      margin-bottom: 8px;
    }

    .field { margin-bottom: 20px; }

    input {
      width: 100%;
      background: var(--bg);
      border: 1px solid var(--border);
      color: var(--text);
      font-family: var(--mono);
      font-size: 14px;
      padding: 12px 14px;
      outline: none;
      transition: border-color .2s;
    }
    input:focus { border-color: var(--accent); }
    input::placeholder { color: var(--muted); }

    button {
      width: 100%;
      padding: 14px;
      margin-top: 8px;
      background: transparent;
      border: 1px solid var(--accent);
      color: var(--accent);
      font-family: var(--mono);
      font-size: 13px;
      letter-spacing: 2px;
      text-transform: uppercase;
      cursor: pointer;
      transition: background .2s, color .2s;
    }
    button:hover { background: var(--accent); color: var(--bg); }
    button:disabled { opacity: .4; cursor: not-allowed; }

    #msg {
      min-height: 20px;
      margin-top: 16px;
      font-family: var(--mono);
      font-size: 12px;
      color: var(--danger);
      text-align: center;
    }
    #msg.ok { color: var(--accent2); }

    .status-dot {
      display: inline-block;
      width: 7px; height: 7px;
      border-radius: 50%;
      background: var(--muted);
      margin-right: 6px;
      vertical-align: middle;
      transition: background .4s;
    }
    .status-dot.online { background: var(--accent2); box-shadow: 0 0 6px var(--accent2); }

    .api-status {
      margin-top: 24px;
      padding-top: 16px;
      border-top: 1px solid var(--border);
      font-family: var(--mono);
      font-size: 11px;
      color: var(--muted);
    }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(20px); }
      to   { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="logo">SENAI // IoT System</div>
    <h1>Acesso ao<br><span>Painel de Controle</span></h1>

    <div class="field">
      <label for="user">Usuário</label>
      <input type="text" id="user" placeholder="login" autocomplete="username">
    </div>

    <div class="field">
      <label for="pass">Senha</label>
      <input type="password" id="pass" placeholder="••••••••" autocomplete="current-password">
    </div>

    <button id="btn" onclick="logar()">Entrar</button>
    <div id="msg"></div>

    <div class="api-status">
      <span class="status-dot" id="dot"></span>
      <span id="api-txt">verificando API...</span>
    </div>
  </div>

  <script>
    const API = 'http://127.0.0.1:5000';

    // Atalho dev: Ctrl+Shift+L
    // REMOVER ANTES DE APRESENTAR
    window.addEventListener('keydown', e => {
      if (e.ctrlKey && e.shiftKey && e.key === 'L') {
        document.getElementById('user').value = 'admin';
        document.getElementById('pass').value = '123';
        logar();
      }
    });

    async function checarAPI() {
      const dot = document.getElementById('dot');
      const txt = document.getElementById('api-txt');
      try {
        const r = await fetch(`${API}/status`, { signal: AbortSignal.timeout(3000) });
        const d = await r.json();
        dot.classList.add('online');
        txt.textContent = `API online · banco: ${d.banco}`;
      } catch {
        txt.textContent = 'API offline';
      }
    }

    async function logar() {
      const login = document.getElementById('user').value.trim();
      const senha = document.getElementById('pass').value;
      const msg   = document.getElementById('msg');
      const btn   = document.getElementById('btn');

      if (!login || !senha) { msg.textContent = 'Preencha todos os campos.'; return; }

      msg.className = '';
      msg.textContent = 'Autenticando...';
      btn.disabled = true;

      try {
        const res  = await fetch(`${API}/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ login, senha }),
          signal: AbortSignal.timeout(5000)
        });
        const data = await res.json();

        if (res.ok) {
          // Salva sessão mínima — nunca salve a senha
          sessionStorage.setItem('usuario', data.nome);
          sessionStorage.setItem('perfil',  data.perfil);
          msg.className = 'ok';
          msg.textContent = `Bem-vindo, ${data.nome}!`;
          setTimeout(() => window.location.href = 'dashboard.html', 600);
        } else {
          msg.textContent = data.detail || 'Acesso negado.';
          btn.disabled = false;
        }
      } catch {
        msg.textContent = 'API offline ou sem resposta.';
        btn.disabled = false;
      }
    }

    // Enter para logar
    document.addEventListener('keydown', e => { if (e.key === 'Enter') logar(); });

    checarAPI();
    setInterval(checarAPI, 10000);
  </script>
</body>
</html>
